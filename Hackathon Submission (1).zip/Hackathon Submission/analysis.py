import pandas as pd
import sqlite3
from config import DATABASE_FILE, CSV_FILE

def load_trade_data():
    """Loads trade data from the database into a Pandas DataFrame."""
    conn = sqlite3.connect(DATABASE_FILE)
    df = pd.read_sql_query("SELECT * FROM trade_records", conn)
    conn.close()
    return df

def export_to_csv(df):
    """Exports the trade data to a CSV file."""
    df.to_csv(CSV_FILE, index=False)
    print(f"Trade data exported to {CSV_FILE}")

df = load_trade_data()
export_to_csv(df)
