import matplotlib.pyplot as plt
import pandas as pd
from config import OUTPUT_PLOT
from analysis import load_trade_data

df = load_trade_data()

if df.empty:
    print("No trade data available for visualization.")
else:
    plt.figure(figsize=(12, 6))
    color_map = {"Binance": "purple", "Uniswap V2": "red", "Uniswap V3": "blue", "Cowswap": "green"}

    for market in df["market"].unique():
        subset = df[df["market"] == market]
        plt.scatter(subset["trade_value"], subset["exec_price"], label=market, alpha=0.7, 
                    color=color_map.get(market, "gray"), s=30)

    plt.axhline(y=df["binance_ref_price"].mean(), color='black', linestyle='--', label="Binance Mid-Price")
    plt.xlabel("Trade Value (USD)")
    plt.ylabel("Executed Price (USD)")
    plt.title("Trade Value vs. Executed Price Across Markets")
    plt.legend()
    plt.grid(True)
    plt.savefig(OUTPUT_PLOT)
    plt.show()
    print(f"Trade visualization saved as {OUTPUT_PLOT}")
