import os
from datetime import datetime

# Timeframe for trade collection
START_PERIOD = datetime(2024, 1, 1)
END_PERIOD = datetime(2024, 2, 1)

# Database settings
DATABASE_FILE = "trade_data.db"

# Output Files
CSV_FILE = "trade_records.csv"
OUTPUT_PLOT = "trade_analysis.png"
