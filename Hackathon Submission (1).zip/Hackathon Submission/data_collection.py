import random
import sqlite3
from config import START_PERIOD, END_PERIOD, DATABASE_FILE
import time

# Convert to Unix timestamps
START_UNIX = int(START_PERIOD.timestamp())
END_UNIX = int(END_PERIOD.timestamp())

def create_mock_trades(market, trade_count=500):
    """Generate simulated trade data for debugging."""
    trades = []
    for _ in range(trade_count):
        trades.append({
            "market": market,
            "trade_value": round(random.uniform(10, 10000), 2),
            "exec_price": round(random.uniform(1000, 5000), 2),
            "binance_ref_price": round(random.uniform(1000, 5000), 2) + random.uniform(-50, 50),
            "trade_time": random.randint(START_UNIX, END_UNIX)
        })
    return trades

# Generate trades for each exchange
mock_binance_trades = create_mock_trades("Binance")
mock_uniswap_v2_trades = create_mock_trades("Uniswap V2")
mock_uniswap_v3_trades = create_mock_trades("Uniswap V3")
mock_cowswap_trades = create_mock_trades("Cowswap")

# Save to database
from database_manager import save_trades_to_db
save_trades_to_db(mock_binance_trades)
save_trades_to_db(mock_uniswap_v2_trades)
save_trades_to_db(mock_uniswap_v3_trades)
save_trades_to_db(mock_cowswap_trades)

print("Trade data collected and saved to database.")
