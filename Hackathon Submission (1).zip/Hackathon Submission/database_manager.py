import sqlite3
from config import DATABASE_FILE

def setup_database():
    """Creates the SQLite database and table if not exists."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS trade_records (
            market TEXT,
            trade_value REAL,
            exec_price REAL,
            binance_ref_price REAL,
            trade_time INTEGER
        )
    ''')
    conn.commit()
    conn.close()

def save_trades_to_db(trades):
    """Inserts trade records into the database."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    for trade in trades:
        cursor.execute("INSERT INTO trade_records VALUES (?, ?, ?, ?, ?)",
                       (trade["market"], trade["trade_value"], trade["exec_price"], trade["binance_ref_price"], trade["trade_time"]))
    conn.commit()
    conn.close()

# Run setup on import
setup_database()
